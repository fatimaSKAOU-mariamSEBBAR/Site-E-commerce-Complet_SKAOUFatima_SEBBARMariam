<?php
require 'connection.php';
    $email = filter_var($_POST["email"], FILTER_SANITIZE_STRING);
    $comment = filter_var($_POST["comment"], FILTER_SANITIZE_STRING);
  
   
    
     function email_valide($email)
{
    if (filter_var($email, FILTER_VALIDATE_EMAIL)) {
      return true;
    } 
    else 
        return false;

}  



function insertCommentRecord($email, $comment)
{
    $passwordHash = md5($password);
    $bdd = new PDO('mysql:host=localhost;dbname=pcosm;charset=utf8', 'root', '');

    $reponse = $bdd->prepare("INSERT INTO comment (email,comment) VALUES('$email','$comment')");
$reponse->execute();
}



if ($_POST["commentaire"]=="envoyer") {
    $k=0;
      
   
    
      if (email_valide($email) != true)
{
	echo "Email  non valide<br>";	
          $k++;
}


   
        if($k==0)
        {
            insertCommentRecord($email,$comment);
                header("Location: index.php");
        }
            
       
        }
        
        
        

?>