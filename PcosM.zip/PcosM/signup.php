<?php
require 'connection.php';
    $name = filter_var($_POST["name"], FILTER_SANITIZE_STRING);
    $password = filter_var($_POST["password"], FILTER_SANITIZE_STRING);
    $email = filter_var($_POST["email"], FILTER_SANITIZE_STRING);
    $adresse = filter_var($_POST["adresse"], FILTER_SANITIZE_STRING);
    $tel = filter_var($_POST["tel"], FILTER_SANITIZE_STRING);
    $password = trim($password);
    $password = stripslashes($password);
    $password = htmlspecialchars($password);
   
    function pwd_valide($pwd)
    {
        if(strlen ($pwd)<8)
        {
            return false ;
        }
    else if (!preg_match('/[0-9]/',$pwd) ||!preg_match('/[A-Z]/',$pwd) || !preg_match('/[a-z]/',$pwd) || !preg_match('/[*&%$#@!?]/',$pwd))
        {
            return false ;
        }
        else 
        return true;

    }

    
     function email_valide($email)
{
    if (filter_var($email, FILTER_VALIDATE_EMAIL)) {
      return true;
    } 
    else 
        return false;

}  

 function tel_valide($tel)
    {
        
    if(!preg_match('`[0-9]{10}`',$tel))
        {
            return false ;
        }
        else 
        {
        return true;
        }
    }

function email_duplique($email)
{
    $bdd = new PDO('mysql:host=localhost;dbname=pcosm;charset=utf8', 'root', '');

    $reponse = $bdd->query("SELECT * FROM user WHERE email= '$email' AND type_user='client'");
while($donnees= $reponse->fetch())    	 			
{
    return 1;
}
}


function validateMember()
{
    $valid = true;
    $errorMessage = array();
    foreach ($_POST as $key => $value) {
        if (empty($_POST[$key])) {
            $valid = false;
        }
    }
    
    if($valid == true) {
        if ($_POST['password'] != $_POST['repassword']) {
            $errorMessage[] = 'Passwords should be same.';
            $valid = false;
        }
        
        if (! isset($error_message)) {
            if (! filter_var($_POST["email"], FILTER_VALIDATE_EMAIL)) {
                $errorMessage[] = "Invalid email address.";
                $valid = false;
            }
        }
        
    }
    else {
        $errorMessage[] = "All fields are required.";
    }
    
    if ($valid == false) {
        return $errorMessage;
    }
    return;
}




function insertMemberRecord($name, $adresse, $tel, $email,  $password,$type)
{
    $passwordHash = md5($password);
    $bdd = new PDO('mysql:host=localhost;dbname=pcosm;charset=utf8', 'root', '');

    $reponse = $bdd->prepare("INSERT INTO user (nom_user,adresse_user,tel_user,email,password,type_user) VALUES('$name','$adresse','$tel','$email','$passwordHash','client')");
$reponse->execute();
}



if ($_POST["envoi"]=="add") {
    $k=0;
     validateMember();
      
    if (pwd_valide($password) != true)
    {
        echo "Mot de passe non valide!<br>";	
        $k++;
    }
  
    
      if (email_valide($email) != true)
{
	echo "Email  non valide<br>";	
          $k++;
}

   
    if (tel_valide($tel) != true)
{
	echo "Numero de telephone non valide<br>";	
          $k++;
}

    
      if (email_duplique($email) == 1)
{
	echo "Email existe déja!<br>";	
          $k++;
}


   
        if($k==0)
        {
            insertMemberRecord($name,$adresse,$tel, $email, $password,"client");
                header("Location: index.php");
        }
            
        } else {
            $errorMessage[] = "User already exists.";
        }
        
        
        

?>