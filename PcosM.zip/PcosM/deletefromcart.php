<?php
 session_start();
      //Put session start at the beginning of the file

require 'connection.php';


if ($_POST["envoi"]=="Supprimer") {
    $idc=$_POST["iduser"];
    $idp=$_POST["idproduit"];
    $datec=$_POST["datecommande"];

   $pf =$_SESSION['pf'];



    $bdd = new PDO('mysql:host=localhost;dbname=pcosm;charset=utf8', 'root', '');
    $reponse = $bdd->prepare("DELETE FROM commande WHERE id_client=$idc AND id_produit=$idp AND date_commande='$datec'");
$reponse->execute();
    
                header("Location: portfolio".$pf.".php");

  
}

?>