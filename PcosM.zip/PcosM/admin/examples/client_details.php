 <?php
session_start();
                ?> 

<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8" />
  <link rel="apple-touch-icon" sizes="76x76" href="../assets/img/apple-icon.png">
  <link rel="icon" type="image/png" href="../assets/img/favicon.png">
  <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
  <title>
      Administrateur-Clients
  </title>
  <meta content='width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0, shrink-to-fit=no' name='viewport' />
  <!--     Fonts and icons     -->
  <link href="https://fonts.googleapis.com/css?family=Montserrat:400,700,200" rel="stylesheet" />
  <link href="https://maxcdn.bootstrapcdn.com/font-awesome/latest/css/font-awesome.min.css" rel="stylesheet">
  <!-- CSS Files -->
  <link href="../assets/css/bootstrap.min.css" rel="stylesheet" />
  <link href="../assets/css/paper-dashboard.css?v=2.0.1" rel="stylesheet" />
  <!-- CSS Just for demo purpose, don't include it in your project -->
  <link href="../assets/demo/demo.css" rel="stylesheet" />
</head>

<body class="">
  <div class="wrapper ">
    <div class="sidebar" data-color="white" data-active-color="danger">
      <div class="logo">
        <a href="https://www.creative-tim.com" class="simple-text logo-mini">
          <div class="logo-image-small">
            <img src="../assets/img/default-avatar.png">
          </div>
          <!-- <p>CT</p> -->
        </a>
        <a href="https://www.creative-tim.com" class="simple-text logo-normal">
          Skaou-Sebbar
          <!-- <div class="logo-image-big">
            <img src="../assets/img/logo-big.png">
          </div> -->
        </a>
      </div>
      <div class="sidebar-wrapper">
        <ul class="nav">
          <li class="active ">
            <a href="./dashboard.php">
              <i class="nc-icon nc-single-02"></i>
              <p>Clients</p>
            </a>
          </li>
          <li>
            <a href="./comments.php">
              <i class="nc-icon nc-single-copy-04"></i>
              <p>Commentaires</p>
            </a>
          </li>
          <li>
            <a href="./messages.php">
              <i class="nc-icon nc-chat-33"></i>
              <p>Messages</p>
            </a>
          </li>
     
          <li>
           
        </ul>
      </div>
    </div>
    <div class="main-panel">
      <!-- Navbar -->
      <nav class="navbar navbar-expand-lg navbar-absolute fixed-top navbar-transparent">
        <div class="container-fluid">
          <div class="navbar-wrapper">
            <div class="navbar-toggle">
              <button type="button" class="navbar-toggler">
                <span class="navbar-toggler-bar bar1"></span>
                <span class="navbar-toggler-bar bar2"></span>
                <span class="navbar-toggler-bar bar3"></span>
              </button>
            </div>
            <a class="navbar-brand" href="javascript:;">Administrateur PcosM</a>
          </div>
          <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navigation" aria-controls="navigation-index" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-bar navbar-kebab"></span>
            <span class="navbar-toggler-bar navbar-kebab"></span>
            <span class="navbar-toggler-bar navbar-kebab"></span>
          </button>
          <div class="collapse navbar-collapse justify-content-end" id="navigation">
           
            <ul class="navbar-nav">
             
              <li class="nav-item">
                <a class="nav-link btn-rotate" href="../../deconnexion.php">
                  <i class="nc-icon nc-button-power"></i>
                  <p>
                    <span class="d-lg-none d-md-block">Account</span>
                  </p>
                </a>
              </li>
            </ul>
          </div>
        </div>
      </nav>
      <!-- End Navbar -->
       
        
        
        
        <br><br><br>
    <h4>Les produits commandés:</h4>
<table style="border: thin solid black;
border-collapse: collapse;
width: 80%;margin:auto;">
  <tr>
      <th style="font-family: monospace;
width: 20%;height:60px;
                 text-align: center;
background-color:black;
color:white;
padding: 5px;">Photo</th>
      
      <th style="font-family: monospace;
width: 20%;height:60px;
                 text-align: center;
background-color:black;
color:white;
padding: 5px;">Catégorie</th>
      
    <th style="font-family: monospace;
width: 20%;height:60px;
               text-align: center;
background-color:black;
color:white;
padding: 5px;">Produit</th>
      
    <th style="font-family: monospace;
width: 10%;height:60px;
               text-align: center;
background-color:black;
color:white;
padding: 5px;">Prix</th>
      
      <th style="font-family: monospace;
width: 10%;height:60px;
                 text-align: center;
background-color:black;
color:white;
padding: 5px;">Quantité</th>
      
      <th style="font-family: monospace;
width: 30%;height:60px;
                 text-align: center;
background-color:black;
color:white;
padding: 5px;">Prix Total</th>
  </tr>
                  
         
                          <?php 
if ($_POST["envoi"]=="Reserver") {
    $idd=$_POST["iduser"];
                $bdd = new PDO('mysql:host=localhost;dbname=pcosm;charset=utf8', 'root', '');

                  $reponse = $bdd->query("SELECT * FROM commande WHERE id_client=$idd");
                $iii=0;
                $iii2=0;
while($donnees= $reponse->fetch())   
{
                $ii= $donnees['id_produit'];

        $reponse2 = $bdd->query("SELECT * FROM produit WHERE id_produit=$ii");
    while($donnees2= $reponse2->fetch())   
{
            $ii2= $donnees2['id_scategorie'];

     $reponse3 = $bdd->query("SELECT * FROM sous_categorie WHERE id_scategorie=$ii2");
        while($donnees3= $reponse3->fetch())   
{
              $ii3= $donnees3['id_categorie'];

     $reponse4 = $bdd->query("SELECT * FROM categorie WHERE id_categorie=$ii3");
              while($donnees4= $reponse4->fetch())   
{
    ?>

<tr style="border: thin solid black;
">

            <td style="font-family: sans-serif;
border: thin solid black;
width: 20%;
padding: 5px;
text-align: center;
background-color: #ffffff;"> <img  src="../../img/Produits/<?php echo  $donnees2['photo_produit'] ?>" alt="First slide" style="width 80px;height:80px;"></td>
      
      
      <td style="font-family: sans-serif;
border: thin solid black;
width: 20%;
padding: 5px;
text-align: center;
background-color: #ffffff;"><?php echo $donnees4['nom_categorie']?></td>
      
    <td style="font-family: sans-serif;
border: thin solid black;
width: 20%;
padding: 5px;
text-align: center;
background-color: #ffffff;"><?php echo $donnees2['nom_produit']?></td>
      
    <td style="font-family: sans-serif;
border: thin solid black;
width: 10%;
padding: 5px;
text-align: center;
background-color: #ffffff;"><?php echo $donnees2['prix']?>,00</td>
      
       <td style="font-family: sans-serif;
border: thin solid black;
width: 10%;
padding: 5px;
text-align: center;
background-color: #ffffff;"><?php echo $donnees['qtt_commande']?></td>
      
    <td style="font-family: sans-serif;
border: thin solid black;
width: 30%;
padding: 5px;
text-align: center;
background-color: #ffffff;"><?php $iii =($donnees2['prix']*$donnees['qtt_commande']);         $iii2=$iii2+$iii;
echo $donnees2['prix']*$donnees['qtt_commande'] ; $_SESSION['idp'] = $donnees['id_produit']; $_SESSION['dp'] = $donnees['date_commande']; $_SESSION['idu'] = $donnees['id_client'];?>,00</td>
    
  
  </tr>


<?php
                
              }}}}
        
?>

      </table>
        <br>
        <container>
       <form method="post" action="suppression_client.php"> <input type="hidden" id="iduser" name="iduser" value="<?php echo $idd?>">
        <button type="submit" class="btn btn-default" aria-label="Left Align" style="background-color:red;margin:auto" name="envoi" value="supprimer">Supprimer le compte
</button>
            </form>
            </container>
        <?php
            }
    ?>
      <footer class="footer footer-black  footer-white ">
        <div class="container-fluid">
          <div class="row">
          
            <div class="credits ml-auto">
              <span class="copyright">
                © <script>
                  document.write(new Date().getFullYear())
                </script>, made with <i class="fa fa-heart heart"></i> by Skaou-Sebbar
              </span>
            </div>
          </div>
        </div>
      </footer>
    </div>
  </div>
  <!--   Core JS Files   -->
  <script src="../assets/js/core/jquery.min.js"></script>
  <script src="../assets/js/core/popper.min.js"></script>
  <script src="../assets/js/core/bootstrap.min.js"></script>
  <script src="../assets/js/plugins/perfect-scrollbar.jquery.min.js"></script>
  <!--  Google Maps Plugin    -->
  <script src="https://maps.googleapis.com/maps/api/js?key=YOUR_KEY_HERE"></script>
  <!-- Chart JS -->
  <script src="../assets/js/plugins/chartjs.min.js"></script>
  <!--  Notifications Plugin    -->
  <script src="../assets/js/plugins/bootstrap-notify.js"></script>
  <!-- Control Center for Now Ui Dashboard: parallax effects, scripts for the example pages etc -->
  <script src="../assets/js/paper-dashboard.min.js?v=2.0.1" type="text/javascript"></script><!-- Paper Dashboard DEMO methods, don't include it in your project! -->
  <script src="../assets/demo/demo.js"></script>
  <script>
    $(document).ready(function() {
      // Javascript method's body can be found in assets/assets-for-demo/js/demo.js
      demo.initChartsPages();
    });
  </script>
</body>

</html>

