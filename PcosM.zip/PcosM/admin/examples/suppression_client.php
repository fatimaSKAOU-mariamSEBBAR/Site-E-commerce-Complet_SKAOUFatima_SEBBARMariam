
<?php 
if ($_POST["envoi"]=="supprimer") {
    $idd=$_POST["iduser"];
                $bdd = new PDO('mysql:host=localhost;dbname=pcosm;charset=utf8', 'root', '');
     $reponse = $bdd->prepare("DELETE FROM user WHERE id_user='$idd'");
$reponse->execute();
            header('Location: dashboard.php');

}
    
?>