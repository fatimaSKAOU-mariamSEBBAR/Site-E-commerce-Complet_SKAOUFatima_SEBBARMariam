<?php
require 'connection.php';
    $nom = filter_var($_POST["nom"], FILTER_SANITIZE_STRING);
    $email = filter_var($_POST["email"], FILTER_SANITIZE_STRING);
    $sujet = filter_var($_POST["sujet"], FILTER_SANITIZE_STRING);
    $message = filter_var($_POST["message"], FILTER_SANITIZE_STRING);
    $date = date("Y-m-d H:i");
  
   
    
     function email_valide($email)
{
    if (filter_var($email, FILTER_VALIDATE_EMAIL)) {
      return true;
    } 
    else 
        return false;

}  



function insertmessageRecord($email, $message,$sujet,$nom,$date)
{
    $bdd = new PDO('mysql:host=localhost;dbname=pcosm;charset=utf8', 'root', '');

    $reponse = $bdd->prepare("INSERT INTO contact (nom,email,sujet,message,date) VALUES('$nom','$email','$sujet','$message','$date')");
$reponse->execute();
}



if ($_POST["contact"]=="envoyer") {
    $k=0;
      
   
    
      if (email_valide($email) != true)
{
	echo "Email  non valide<br>";	
          $k++;
}


   
        if($k==0)
        {
            insertmessageRecord($email,$message,$sujet,$nom,$date);
             header("Location: contact.php");
        }
            
       
        }
        
        
        

?>